from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SearchProEndpoint:
    name: str
    method: str
    path: str


SEARCH_PRO_ENDPOINTS: tuple[SearchProEndpoint, ...] = (
    SearchProEndpoint("industry_news_viewpoints", "POST", "/api/v1/search/industry_news_viewpoints"),
    SearchProEndpoint("single_stock_analysis", "POST", "/api/v1/stock/single_stock_analysis"),
    SearchProEndpoint("single_stock_market_daily_analysis", "POST", "/api/v1/stock/single_stock_market_daily_analysis"),
    SearchProEndpoint("income", "POST", "/api/v1/stock/income"),
    SearchProEndpoint("cashflow", "POST", "/api/v1/stock/cashflow"),
    SearchProEndpoint("fina_mainbz", "POST", "/api/v1/stock/fina_mainbz"),
    SearchProEndpoint("balancesheet", "POST", "/api/v1/stock/balancesheet"),
    SearchProEndpoint("top10_holders", "POST", "/api/v1/stock/top10_holders"),
    SearchProEndpoint("daily", "POST", "/api/v1/stock/daily"),
    SearchProEndpoint("monthly", "POST", "/api/v1/stock/monthly"),
    SearchProEndpoint("stock_basic", "POST", "/api/v1/stock/stock_basic"),
    SearchProEndpoint("stk_managers", "POST", "/api/v1/stock/stk_managers"),
    SearchProEndpoint("industry_crowding_analysis", "POST", "/api/v1/sector/industry_crowding_analysis"),
    SearchProEndpoint("industry_leader_mktcap_analysis", "POST", "/api/v1/sector/industry_leader_mktcap_analysis"),
    SearchProEndpoint("industry_leader_financial_analysis", "POST", "/api/v1/sector/industry_leader_financial_analysis"),
    SearchProEndpoint("industry_market_analysis", "POST", "/api/v1/sector/industry_market_analysis"),
    SearchProEndpoint("industry_financial_analysis", "POST", "/api/v1/sector/industry_financial_analysis"),
    SearchProEndpoint("industry_valuation_analysis", "POST", "/api/v1/sector/industry_valuation_analysis"),
    SearchProEndpoint("industry_knowledge_graph", "POST", "/api/v1/sector/industry_knowledge_graph"),
    SearchProEndpoint("funds_info", "POST", "/api/v1/funds/info"),
    SearchProEndpoint("funds_market", "POST", "/api/v1/funds/market"),
    SearchProEndpoint("indexes_info", "POST", "/api/v1/indexes/info"),
    SearchProEndpoint("indexes_market", "POST", "/api/v1/indexes/market"),
    SearchProEndpoint("market_report", "POST", "/api/v1/special/market_report"),
    SearchProEndpoint("anomaly_sector", "POST", "/api/v1/special/anomaly_sector"),
    SearchProEndpoint("anomaly_sector_analyze", "POST", "/api/v1/special/anomaly_sector_analyze"),
    SearchProEndpoint("stocks_cot_data", "POST", "/api/v1/special/stocks_cot_data"),
    SearchProEndpoint("limit_info", "POST", "/api/v1/special/limit_info"),
    SearchProEndpoint("continuous_limit", "GET", "/api/v1/special/continuous_limit"),
    SearchProEndpoint("realtime_anomaly_stock", "GET", "/api/v1/special/realtime_anomaly_stock"),
)


SEARCH_PRO_ENDPOINTS_BY_NAME: dict[str, SearchProEndpoint] = {
    endpoint.name: endpoint for endpoint in SEARCH_PRO_ENDPOINTS
}
