from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SearchProEndpoint:
    name: str
    method: str
    path: str


SEARCH_PRO_ENDPOINTS: tuple[SearchProEndpoint, ...] = (
    SearchProEndpoint("analyze_chunks", "POST", "/api/v1/search/analyze_chunks"),
    SearchProEndpoint("auto_select_stocks", "POST", "/api/v1/search/auto_select_stocks"),
    SearchProEndpoint("auto_select_funds", "POST", "/api/v1/search/auto_select_funds"),
    SearchProEndpoint("industry_news_viewpoints", "POST", "/api/v1/search/industry_news_viewpoints"),
    SearchProEndpoint("internet_news", "POST", "/api/v1/search/internet_news"),
    SearchProEndpoint("single_stock_analysis", "POST", "/api/v1/stock/single_stock_analysis"),
    SearchProEndpoint("single_stock_market_daily_analysis", "POST", "/api/v1/stock/single_stock_market_daily_analysis"),
    SearchProEndpoint("income", "POST", "/api/v1/stock_data/stock/income"),
    SearchProEndpoint("cashflow", "POST", "/api/v1/stock_data/stock/cashflow"),
    SearchProEndpoint("fina_mainbz", "POST", "/api/v1/stock_data/stock/fina_mainbz"),
    SearchProEndpoint("balancesheet", "POST", "/api/v1/stock_data/stock/balancesheet"),
    SearchProEndpoint("top10_holders", "POST", "/api/v1/stock_data/stock/top10_holders"),
    SearchProEndpoint("daily", "POST", "/api/v1/stock_data/stock/daily"),
    SearchProEndpoint("monthly", "POST", "/api/v1/stock_data/stock/monthly"),
    SearchProEndpoint("stock_basic", "POST", "/api/v1/stock_data/stock/stock_basic"),
    SearchProEndpoint("stk_managers", "POST", "/api/v1/stock_data/stock/stk_managers"),
    SearchProEndpoint("industry_crowding_analysis", "POST", "/api/v1/sector/industry_crowding_analysis"),
    SearchProEndpoint("industry_leader_mktcap_analysis", "POST", "/api/v1/sector/industry_leader_mktcap_analysis"),
    SearchProEndpoint("industry_leader_financial_analysis", "POST", "/api/v1/sector/industry_leader_financial_analysis"),
    SearchProEndpoint("industry_market_analysis", "POST", "/api/v1/sector/industry_market_analysis"),
    SearchProEndpoint("industry_financial_analysis", "POST", "/api/v1/sector/industry_financial_analysis"),
    SearchProEndpoint("industry_valuation_analysis", "POST", "/api/v1/sector/industry_valuation_analysis"),
    SearchProEndpoint("industry_knowledge_graph", "POST", "/api/v1/sector/industry_knowledge_graph"),
    SearchProEndpoint("funds_info", "POST", "/api/v1/funds/info"),
    SearchProEndpoint("funds_market", "POST", "/api/v1/funds/market"),
    SearchProEndpoint("indexes_info", "POST", "/api/v1/indexes/info"),
    SearchProEndpoint("indexes_market", "POST", "/api/v1/indexes/market"),
    SearchProEndpoint("market_report", "POST", "/api/v1/special/market_report"),
    SearchProEndpoint("anomaly_sector", "POST", "/api/v1/special/anomaly_sector"),
    SearchProEndpoint("anomaly_sector_analyze", "POST", "/api/v1/special/anomaly_sector_analyze"),
    SearchProEndpoint("asset_daily_backtest", "POST", "/api/v1/special/asset_daily_backtest"),
    SearchProEndpoint("stocks_cot_data", "POST", "/api/v1/special/stocks_cot_data"),
    SearchProEndpoint("limit_info", "POST", "/api/v1/special/limit_info"),
    SearchProEndpoint("continuous_limit", "GET", "/api/v1/special/continuous_limit"),
    SearchProEndpoint("realtime_anomaly_stock", "GET", "/api/v1/special/realtime_anomaly_stock"),
    SearchProEndpoint("get_cot_report", "POST", "/api/v1/reports/get_cot_report"),
)


SEARCH_PRO_ENDPOINTS_BY_NAME: dict[str, SearchProEndpoint] = {
    endpoint.name: endpoint for endpoint in SEARCH_PRO_ENDPOINTS
}
