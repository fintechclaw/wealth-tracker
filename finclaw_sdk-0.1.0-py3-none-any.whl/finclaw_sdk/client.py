from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from .routes import SEARCH_PRO_ENDPOINTS, SEARCH_PRO_ENDPOINTS_BY_NAME, SearchProEndpoint


def _decode_response(response: httpx.Response) -> Any:
    content_type = response.headers.get("content-type", "")
    if "application/json" in content_type:
        return response.json()
    return response.text


@dataclass(frozen=True, slots=True)
class FinclawApiError(Exception):
    endpoint_name: str
    status_code: int
    payload: Any

    def __str__(self) -> str:
        return f"Finclaw API request failed for {self.endpoint_name} with status {self.status_code}: {self.payload!r}"


class _BaseFinclawClient:
    def _resolve_endpoint(self, endpoint_name: str) -> SearchProEndpoint:
        endpoint = SEARCH_PRO_ENDPOINTS_BY_NAME.get(endpoint_name)
        if endpoint is None:
            raise ValueError(f"unknown_endpoint: {endpoint_name}")
        return endpoint

    def _build_request_kwargs(
        self,
        endpoint: SearchProEndpoint,
        *,
        payload: Any = None,
        params: dict[str, Any] | None,
    ) -> dict[str, Any]:
        request_kwargs: dict[str, Any] = {}
        if endpoint.method.upper() == "GET":
            if payload is not None and not isinstance(payload, dict):
                raise TypeError(f"get_endpoint_requires_mapping_payload: {endpoint.name}")
            resolved_params = params if params is not None else payload
            if resolved_params is not None:
                request_kwargs["params"] = resolved_params
            return request_kwargs
        if payload is not None:
            request_kwargs["json"] = payload
        if params is not None:
            request_kwargs["params"] = params
        return request_kwargs

    def _raise_for_error(self, endpoint: SearchProEndpoint, response: httpx.Response) -> None:
        if response.is_success:
            return
        raise FinclawApiError(
            endpoint_name=endpoint.name,
            status_code=response.status_code,
            payload=_decode_response(response),
        )


class FinclawClient(_BaseFinclawClient):
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "http://103.219.92.158:37788",
        timeout: float = 30.0,
        headers: dict[str, str] | None = None,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        resolved_headers = {"x-api-key": api_key}
        if headers:
            resolved_headers.update(headers)
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            timeout=timeout,
            headers=resolved_headers,
            transport=transport,
        )

    def request(
        self,
        endpoint_name: str,
        *,
        payload: Any = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        endpoint = self._resolve_endpoint(endpoint_name)
        response = self._client.request(
            endpoint.method,
            endpoint.path,
            **self._build_request_kwargs(endpoint, payload=payload, params=params),
        )
        self._raise_for_error(endpoint, response)
        return _decode_response(response)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "FinclawClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


class AsyncFinclawClient(_BaseFinclawClient):
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        timeout: float = 30.0,
        headers: dict[str, str] | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        resolved_headers = {"x-api-key": api_key}
        if headers:
            resolved_headers.update(headers)
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            timeout=timeout,
            headers=resolved_headers,
            transport=transport,
        )

    async def request(
        self,
        endpoint_name: str,
        *,
        payload: Any = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        endpoint = self._resolve_endpoint(endpoint_name)
        response = await self._client.request(
            endpoint.method,
            endpoint.path,
            **self._build_request_kwargs(endpoint, payload=payload, params=params),
        )
        self._raise_for_error(endpoint, response)
        return _decode_response(response)

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncFinclawClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()


def _build_sync_method(endpoint: SearchProEndpoint):
    if endpoint.method.upper() == "GET":
        def method(self: FinclawClient, **params: Any) -> Any:
            return self.request(endpoint.name, params=params or None)
    else:
        def method(self: FinclawClient, **payload: Any) -> Any:
            return self.request(endpoint.name, payload=payload or None)
    method.__name__ = endpoint.name
    method.__doc__ = f"{endpoint.method} {endpoint.path}"
    return method


def _build_async_method(endpoint: SearchProEndpoint):
    if endpoint.method.upper() == "GET":
        async def method(self: AsyncFinclawClient, **params: Any) -> Any:
            return await self.request(endpoint.name, params=params or None)
    else:
        async def method(self: AsyncFinclawClient, **payload: Any) -> Any:
            return await self.request(endpoint.name, payload=payload or None)
    method.__name__ = endpoint.name
    method.__doc__ = f"{endpoint.method} {endpoint.path}"
    return method


def _build_sync_array_body_method(endpoint: SearchProEndpoint):
    def method(self: FinclawClient, items: list[dict[str, Any]]) -> Any:
        return self.request(endpoint.name, payload=items)

    method.__name__ = endpoint.name
    method.__doc__ = f"{endpoint.method} {endpoint.path}"
    return method


def _build_async_array_body_method(endpoint: SearchProEndpoint):
    async def method(self: AsyncFinclawClient, items: list[dict[str, Any]]) -> Any:
        return await self.request(endpoint.name, payload=items)

    method.__name__ = endpoint.name
    method.__doc__ = f"{endpoint.method} {endpoint.path}"
    return method


for _endpoint in SEARCH_PRO_ENDPOINTS:
    setattr(FinclawClient, _endpoint.name, _build_sync_method(_endpoint))
    setattr(AsyncFinclawClient, _endpoint.name, _build_async_method(_endpoint))


_get_cot_report_endpoint = SEARCH_PRO_ENDPOINTS_BY_NAME["get_cot_report"]
setattr(FinclawClient, _get_cot_report_endpoint.name, _build_sync_array_body_method(_get_cot_report_endpoint))
setattr(AsyncFinclawClient, _get_cot_report_endpoint.name, _build_async_array_body_method(_get_cot_report_endpoint))
